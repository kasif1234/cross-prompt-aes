Cross-prompt Automated Essay Scoring System
===========================================

A project to design, train, and evaluate deep learning models for Automated Essay Scoring (AES).


Installation and files
----------------------
Follow these steps to set up the project:

1. Download and unzip the 'G10_code_B.zip' file, this file contains the following contents for Approach B: 
   -'dataset.csv' file containing the data used to train the models.
   -'TrainingCodeB.ipynb' used to train the 8 models and the deployed model.
   -'AESsystemAB.ipynb' containg the code to run the deployed AES system.
   -'ScoresTrackingB' folder containing the results of all the experiments.
   -Example data folder contains data used for input to the system and the predicted output
   
   
2. Download and unzip the 'G10_models_B.zip' file, this file contains:
   -The 8 models trained for each prompt 'model-B-X.pt'
   -The deployed model 'model-B-deploy.pt'


Training
--------
Follow these steps to replicate Training Experiments:

1. place the 'dataset.csv' and 'TrainingCodeB.ipynb' files in the same directory.
2. Run the 'TrainingCodeB.ipynb' code.
3. The training code will create and save 2 files and 2 models for each prompt, 
   along with a deployed model. Resulting in 33 files in total: 
   (X denoting the number of the model):
   'qwk_scores_X_step_1.csv' files contain results from the training step 1.
   'model-B-X-step_1.pt' files are models produced after training step 1.
   'qwk_scores_X_step_2.csv' files contain results from the training step 2.
   'model-B-X.pt' files are models produced after training step 2. (final models)
   'model-B-deploy.pt' is the deployed model.


Using the AES system
--------------------
Follow these steps to use the AES system:

1. place the 'AESsystemAB.ipynb' and 'model-B-deploy.pt' files in the same directory.
2. place the csv file of the essays u want to score, preferably in the same directory
   (U may use the 'Essays to score.csv' file from the 'Example data' folder).
3. Run the 'AESsystemAB.ipynb' code.
4. The system will prompt you to choose an approach A or B
5. The system will prompt u to enter the 'path to the essays to score csv file'.
6. The system will prompt you to enter the path of the deployed model
7. The system will create a file called 'Scored Essays (Approach B).csv'
   containing the holistic scores predicted by the deployed model.

Contributing
------------
Contributions are welcome! Follow these steps to contribute:

1. Clone the project folder to your machine.
2. Experiment with new features or improve the model implementations.
3. Document your changes clearly.
4. Share the updated version with the project team for evaluation.

License
-------
This project is free to use, modify, and share as per your needs.

Contact
-------
For questions or feedback, you can reach out at:

- Email: mk2110389@qu.edu.qa, iz2008203@qu.edu.qa, Ms202007909@qu.edu.qa, rk2107326@qu.edu.qa	

