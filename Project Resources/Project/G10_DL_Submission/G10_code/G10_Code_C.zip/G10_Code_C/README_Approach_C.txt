Cross-prompt Automated Essay Scoring System
===========================================

Running `Approach_C.ipynb` in Google Colab
------------------------------------------
Steps to Run:
1. Upload the Notebook:
   - Open [Google Colab](https://colab.research.google.com).
   - Upload the `trainingCodeC.ipynb` file to Colab.

2. Upload Required Files:
   - Upload the `dataset.csv` file containing essay features.
   - Upload pretrained models (BERT).

3. Install Dependencies:
   - Run the first cell in the notebook to install necessary Python libraries.

4. Execution:
   - Run cells sequentially using Shift + Enter.

5. Outputs:
   - It might run for only 1 or 2 epochs due to memory constraints but gave a relatively high QWKA score



Contributing
------------
Contributions are welcome! Follow these steps to contribute:

1. Clone the project folder to your machine.
2. Experiment with new features or improve the model implementations.
3. Document your changes clearly.
4. Share the updated version with the project team for evaluation.

License
-------
This project is free to use, modify, and share as per your needs.

Contact
-------
For questions or feedback, you can reach out at:

- Email: mk2110389@qu.edu.qa, iz2008203@qu.edu.qa, Ms202007909@qu.edu.qa, rk2107326@qu.edu.qa	

